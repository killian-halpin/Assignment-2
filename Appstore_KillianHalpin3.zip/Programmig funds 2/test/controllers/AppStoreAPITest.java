package controllers;

import static org.junit.jupiter.api.Assertions.*;

class AppStoreAPITest {

}