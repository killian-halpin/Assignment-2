package controller;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

import models.Note;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class NoteAPI {

    private ArrayList<Note> notes;

    public NoteAPI(){
        notes = new ArrayList<Note>();

    }

    public ArrayList<Note> getNotes() {
        return notes;
    }


    /**
     * This method returns the number of notes stored in the ArrayList.
     */
    public int numberOfNotes() {
        return notes.size();
    }

    /**
     *
     * @param index A number representing a potential index in the ArrayList.
     * @return True of the index number passed is a valid index in the ArrayList, false otherwise.
     */
    public boolean isValidIndex(int index) {
        return (index >= 0) && (index < notes.size());
    }


    /**
     * Add the note object, passed as a parameter, to the ArrayList.
     *
     * @param note is an object to be added to the ArrayList.
     */
    public boolean add(Note note){
        notes.add(note);
        return true;
    }


    public Note findNote(int index) {
        if (isValidIndex(index)) {
            return notes.get(index);
        }
        return null;
    }

    public String listAllNotes() {
        if (notes.isEmpty()) {
            return "No notes added";
        } else {
            String listOfNotes = "";
            for (int i = 0; i < notes.size(); i++) {
                listOfNotes += i + ": " + notes.get(i) + "\n";
            }
            return listOfNotes;
        }
    }


    /**
     * Delete a models.Product from the ArrayList, if it exists, at the index passed as a parameter.
     *
     * @param indexToDelete Index of the notes object in the ArrayList
     * @return The deleted note or null if nothing is there
     */
    public Note deleteNote(int indexToDelete) {
        if (isValidIndex(indexToDelete)) {
            return notes.remove(indexToDelete);
        }
        return null;
    }

    public int numberOfArchivedNotes(){
        int counter = 0;
        for(int i = 0;i < notes.size(); i = i +1){
            if(notes.get(i).isNoteArchived() == true){
                counter++;
            }
        }
        return counter;
    }

    public int numberOfActiveNotes(){
        int counter = 0;
        for(int i = 0;i < notes.size(); i = i +1){
            if(notes.get(i).isNoteArchived() == false){
                counter++;
            }
        }
        return counter;
    }

    public int numberOfNotesByCategory(String cats){
        int counter = 0;
        for(int i = 0;i < notes.size(); i = i +1){
            if(notes.get(i).getNoteCategory().equals(cats)){
                counter++;
            }
        }
        return counter;
    }

    public int numberOfNotesByPriority(int pri){
        int counter = 0;
        for(int i = 0;i < notes.size(); i = i +1){
            if(notes.get(i).getNotePriority() == pri){
                counter++;
            }
        }
        return counter;
    }



    /**
     * Update a models.Note in the ArrayList with the contents passed in the models.Note object parameter.
     *
     * @param indexToUpdate Index of the models.Product object in the ArrayList
     * @param noteTitle Title of the note
     * @param notePriority number given to say whether the note is important
     * @param noteCategory sayig what category the note is in
     * @return The status of the update, True or False
     */
    public boolean updateNote(int indexToUpdate,String noteTitle, int notePriority,String noteCategory) {
        //find the product object by the index number
        Note foundNote = findNote(indexToUpdate);

        //if the product exists, use the details passed in the updateDetails parameter to
        //update the found product in the ArrayList.
        if (foundNote != null) {
            foundNote.setNoteTitle(noteTitle);
            foundNote.setNotePriority(notePriority);
            foundNote.setNoteCategory(noteCategory);
            return true;
        }

        //if the note was not found, return false, indicating that the update was not successful
        return false;
    }

    public String listArchivedNotes() {
        if (notes.isEmpty()) {
            return "No Notes Archieved";
        } else {
            String listOfNotes = "";
            for (int i = 0; i < notes.size(); i++) {
                if (notes.get(i).isNoteArchived()){
                    listOfNotes += i + ": " + notes.get(i) + "\n";
                }

            }
            if (listOfNotes.equals("")){
                return "No Notes are archived";
            }
            else{
                return listOfNotes;
            }
        }
    }

    public String listNotesBySelectedCategory(String cats) {
        if (notes.isEmpty()) {
            return "No Notes";
        } else {
            String listOfNotes = "";
            for (int i = 0; i < notes.size(); i++) {
                if (notes.get(i).getNoteCategory().equals(cats)){
                    listOfNotes += i + ": " + notes.get(i) + "\n";
             }
            }
                return listOfNotes;
        }
    }

    public String listNotesBySelectedPriority(int pri) {
        if (notes.isEmpty()) {
            return "No Notes";
        } else {
            String listOfNotes = "";
            for (int i = 0; i < notes.size(); i++) {
                if (notes.get(i).getNotePriority() == pri){
                    listOfNotes += i + ": " + notes.get(i) + "\n";
                }

            }
            return listOfNotes;
        }
    }


    public String listTodoItems() {
        if (notes.isEmpty()) {
            return "No Notes";
        } else {
            String listOfItems = "";
            for (int i = 0; i < notes.size(); i++) {
                for(int k = 0; k < notes.get(i).getItems().size();k++){
                    if(notes.get(i).getItems().get(k).isItemCompleted() == false){
                        listOfItems = listOfItems + notes.get(i).getItems().get(k);
                    }
                }
            }
            return listOfItems;
        }
    }

    public String listItemStatusByCategory(String cats) {
        if (notes.isEmpty()) {
            return "No Notes";
        } else {
            String listOfItems = "";
            for (int i = 0; i < notes.size(); i++) {
                for(int k = 0; k < notes.get(i).getItems().size();k++){       //goes through all completed items by category and says if they are completed or not
                    if(notes.get(i).getNoteCategory().equals(cats)){
                        if(notes.get(i).getItems().get(k).isItemCompleted()){
                            listOfItems = listOfItems + notes.get(i).getItems().get(k);
                        }
                    }
                }
            }
            return listOfItems;
        }
    }

    public String searchItemByDescription(String des){
        if (notes.isEmpty()) {
            return "No Notes";
        } else {
            String listOfItems = "";
            for (int i = 0; i < notes.size(); i++) {
                for(int k = 0; k < notes.get(i).getItems().size();k++){       //goes through all completed items by description
                        if(notes.get(i).getItems().get(k).getItemDescription() == des){
                            listOfItems = listOfItems + notes.get(i).getItems().get(k);
                        }
                }
            }
            return listOfItems;
        }
    }

    public boolean archiveNote(int index){
        if(!isValidIndex(index)){   //if its index is invalid return false
            return  false;
        }

        for (int i = 0; i < notes.size(); i++) {   // if a note is already archived return false
            if (notes.get(i).isNoteArchived() == true){
                return false;
            }
        }
        if(isValidIndex(index)) {
            for (int i = 0; i < notes.size(); i++) {
                if (i == index) {
                    notes.get(i).setNoteArchived(true);
                }
            }
        }
       return true;
    }


    public String archiveNotesWithAllItemsComplete(){
        for (int i = 0; i < notes.size(); i++) {
            for (int k = 0; k < notes.get(i).getItems().size(); k++) {

                if(notes.get(i).getItems().get(k).isItemCompleted()){
                    notes.get(i).setNoteArchived(true);
                }

            }
        }
        return "No active notes stored";
    }



    public int numberOfTodoItems(){
        int counter = 0;
        for (int i = 0; i < notes.size();i++){
            for (int k = 0; k < notes.get(i).getItems().size();k++){
                if (notes.get(i).getItems().get(k).isItemCompleted() == false){
                    counter++;
                }
            }
        }
        return counter;
    }





    public int numberOfItems() {
        int counter = 0;
        for (int i = 0; i < notes.size(); i++) {
            for (int k = 0; k < notes.get(i).getItems().size(); k++) {
                counter++;
            }
        }
        return counter;
    }




    public int numberOfCompleteItems(){
        int counter = 0;
        for (int i = 0; i < notes.size(); i++) {
            for (int k = 0; k < notes.get(i).getItems().size(); k++) {
                if(notes.get(i).getItems().get(k).isItemCompleted() == true){
                    counter++;
                }
            }
        }
        return counter;
    }




    public String listActiveNotes(){
                String listOfActiveNotes = "";
                for (int i = 0; i < notes.size(); i++) {
                    if (notes.get(i).isNoteArchived() == false){
                        listOfActiveNotes = i + "\n";
                    }
                }
                return listOfActiveNotes;
            }




    public String searchNotesByTitle(String A){
        return "";
    }






    /**
     * The load method uses the XStream component to read all the product objects from the products.xml
     * file stored on the hard disk.  The read products are loaded into the products ArrayList
     *
     * @throws Exception  An exception is thrown if an error occurred during the load e.g. a missing file.
     */
    @SuppressWarnings("unchecked")
    public void load() throws Exception {
        //list of classes that you wish to include in the serialisation, separated by a comma
        Class<?>[] classes = new Class[] { Note.class };
        //setting up the xstream object with default security and the above classes
        XStream xstream = new XStream(new DomDriver());
        XStream.setupDefaultSecurity(xstream);
        xstream.allowTypes(classes);
        //doing the actual serialisation to an XML file
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("notes.xml"));
        notes = (ArrayList<Note>) is.readObject();
        is.close();
    }


    /**
     * The save method uses the XStream component to write all the product objects in the products ArrayList
     * to the products.xml file stored on the hard disk.
     *
     * @throws Exception  An exception is thrown if an error occurred during the save e.g. drive is full.
     */
    public void save() throws Exception {
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("notes.xml"));
        out.writeObject(notes);
        out.close();
    }


}
