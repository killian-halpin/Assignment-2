package main;

import controller.NoteAPI;
import models.Item;
import models.Note;
import utils.ScannerInput;


import java.util.Scanner;

public class Driver {

    private Scanner input;
    NoteAPI noteAPI;
    Item item;

    public static void main(String[] args) throws Exception {
        Driver app = new Driver();
        app.runMenu();
    }

    public Driver() {
        input = new Scanner(System.in);
        noteAPI = new NoteAPI();
        mainMenu();
    }

    private int mainMenu() {
        System.out.println("NOTE MENU");
        System.out.println("-------------------");
        System.out.println(" 1) Add a Note");
        System.out.println(" 2) View all Notes");
        System.out.println(" 3) Update a Note");
        System.out.println(" 4) Delete a Note");
        System.out.println(" 5) Archive a Note");
        System.out.println("-------------------");
        System.out.println("ITEM MENU");
        System.out.println(" 6) Add an Item to a Note");
        System.out.println(" 7) Update Item Description on a Note");
        System.out.println(" 8) Delete an Item from a Note");
        System.out.println(" 9) Mark Item as Complete/ TODO");
        System.out.println("-------------------");
        System.out.println("REPORT MENU FOR NOTES");
        System.out.println(" 10) All Notes and Their Items (Active & Archived");
        System.out.println(" 11) Archive Notes Whose Items Are All Complete");
        System.out.println(" 12) All Notes Within a Selected Category");
        System.out.println(" 13) All Notes Within a Selected Priority");
        System.out.println(" 14) Search for All Notes (by Note Title");
        System.out.println("-------------------");
        System.out.println("REPORT MENU FOR ITEMS");
        System.out.println(" 15) All Items That are TOdO (With Note Title)");
        System.out.println(" 16) Overall Number of Items TODO/Complete");
        System.out.println(" 17) TODO/Complete Items by Specific Category");
        System.out.println(" 18) Search for All Items (By Item Description)");
        System.out.println("-------------------");
        System.out.println("SETTINGS MENU");
        System.out.println(" 19) Save");
        System.out.println(" 20) Load");
        System.out.println(" 0) Exit");


        return ScannerInput.readNextInt("---->");

    }


    private void runMenu() throws Exception {
        int option = mainMenu();

        while (option != 0) {

            switch (option) {
                case 1 -> addNote();
                case 2 -> viewAllNotes();
                case 3 -> updateSelectedNote();  //todo
                case 4 -> deleteNote();
                case 5 -> archiveNote();
                case 6 -> addItemToNote(); //todo
                case 7 -> updateDescription(); //todo
                case 8 -> deleteItemFromNote();
              //  case 9 -> markItemCompleteOrToDo();
                case 10 -> allNotes();
//                case 11 -> archiveNotesWithAllItemsComplete();
                case 12 -> allNotesWIthSelectedCategory();
                case 13 -> allNotesInSelectedPriority();
                case 14 -> searchNoteByTitle();
                case 15 -> allItemsToDo();
//                case 16 -> overallItemsToDo();
//                case 17 -> ToDoItemsByCategory();
//                case 18 -> searchAllItems();
                case 19 -> save();
                case 20 -> load();
                case 0 -> exit();
                default -> System.out.println("Invalid option entered: " + option);
            }

            //pause the program so that the user can read what we just printed to the terminal window
            ScannerInput.readNextLine("\nPress enter key to continue...");
            input.nextLine();

            //display the main menu again
            option = mainMenu();
        }
    }


    private void addNote() {
        System.out.println("Note:  ");

        String noteTitle = ScannerInput.readNextLine("Note Title: ");
        int notePriority = ScannerInput.readNextInt("Note Priority: ");
        String noteCategory = ScannerInput.readNextLine("Note Category: ");
        noteAPI.add(new Note(noteTitle, notePriority, noteCategory));
    }

    private void viewAllNotes() {
        System.out.println(noteAPI.listAllNotes());

    }

    private void updateSelectedNote() {


    }

    private void deleteNote() {

        int index = ScannerInput.readNextInt("Note Index to delete: ");
        noteAPI.deleteNote(index);

    }

    private void archiveNote() {
        int index = ScannerInput.readNextInt("Archive note");
        noteAPI.archiveNote(index);
        System.out.println(index + "Has been archived");
    }

    private void addItemToNote() {
        String index = ScannerInput.readNextLine("Add Item to Note");
        String itemDescription = ScannerInput.readNextLine("Item Description: ");
        // noteAPI.add(new Item(itemDescription));
    }

    private void updateDescription() {
        String des = ScannerInput.readNextLine("Please enter item Description");
        System.out.println(noteAPI.searchItemByDescription(des));
    }

    private void allNotesWIthSelectedCategory() {

        String category = ScannerInput.readNextLine("What category of notes would you like to see the number of?");
        noteAPI.numberOfNotesByCategory(category);
    }


    private void allNotesInSelectedPriority() {
        int prioroity = ScannerInput.readNextInt("What priorirty number of notes would you like to see? :");
        System.out.println(noteAPI.numberOfNotesByPriority(prioroity));
    }


    private void searchNoteByTitle() {
        String title = ScannerInput.readNextLine("Give title of note:");
        System.out.println(noteAPI.searchNotesByTitle(title));
    }

    private void allNotes() {
        System.out.println(noteAPI.listAllNotes());
    }


    private void allItemsToDo() {
        String itemsTodo = "";
        for (int i = 0; i < noteAPI.getNotes().size(); i++) {
            for (int k = 0; k < noteAPI.getNotes().get(i).getItems().size(); k++) {
                if (noteAPI.getNotes().get(i).getItems().get(k).isItemCompleted() == false) {
                    System.out.println(noteAPI.getNotes().get(i).getItems().get(k));
                }
            }
        }
    }

    private void deleteItemFromNote() {
        int deletefromnote = ScannerInput.readNextInt("Which item would you like to delete? :");
        System.out.println(noteAPI.deleteNote(deletefromnote));
    }

//    private void markItemCompleteOrToDo() {
//
//        int markcomplete = ScannerInput.readNextInt("Which item would you like to mark");
//        ///boolean m
//        for (int i = 0; i < noteAPI.getNotes().size(); i++) {
//            for (int k = 0; k < noteAPI.getNotes().get(i).getItems().size(); k++)
//                //System.out.println(noteAPI.getNotes().get(i).getItems().get(k).setItemCompleted();
//        }
//    }

    public void save() throws Exception {

        noteAPI.save();
    }

    public void load() throws Exception {

        noteAPI.load();
    }

    private void exit(){
        System.out.println("Exiting...bye");
        System.exit(0);
    }
}
