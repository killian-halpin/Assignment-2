package models;

import jdk.jshell.execution.Util;
import utils.Utilities;

import java.util.ArrayList;
import java.util.Objects;

public class Item {

 private String itemDescription = "No Description";
 private boolean isItemCompleted = false;

 public Item(String itemDescription, boolean isItemCompleted){
  this.itemDescription = Utilities.truncateString(itemDescription,50);
  this.isItemCompleted = true;

 }


 public Item(String itemDescription){

  this.itemDescription = Utilities.truncateString(itemDescription,50);
  this.isItemCompleted = false;

 }

 //Getters and Setters


 public String getItemDescription() {
  return itemDescription;
 }

 public void setItemDescription(String itemDescription) {
  this.itemDescription = Utilities.truncateString(itemDescription,50);
 }

 public boolean isItemCompleted() {
  return isItemCompleted;
 }

 public void setItemCompleted(boolean itemCompleted) {
  isItemCompleted = itemCompleted;
 }

 @Override
 public boolean equals(Object o) {  // Generated equals method
  if (this == o) return true;
  if (o == null || getClass() != o.getClass()) return false;
  Item item = (Item) o;
  return isItemCompleted == item.isItemCompleted && itemDescription.equals(item.itemDescription);
 }




 @Override
 public String toString() {
  return "Item{" +
          "itemDescription='" + itemDescription + '\'' +
          ", isItemCompleted=" + isItemCompleted +
          '}';
 }
}