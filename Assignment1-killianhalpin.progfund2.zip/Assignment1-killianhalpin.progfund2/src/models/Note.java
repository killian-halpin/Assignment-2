package models;
import utils.Utilities;

import java.util.ArrayList;

public class Note {

    private String noteTitle = "No Title";
    private int notePriority = 1;
    private String noteCategory = "";
    private boolean isNoteArchived = false;
    private ArrayList<Item> myItem = new ArrayList<>();

   public Note(String noteTitle,  int notePriority, String noteCategory) {


       if (Utilities.validateStringLength(noteTitle, 20)) {
           this.noteTitle = noteTitle;
       } else if (noteTitle.length() <= 0) {
           this.noteTitle = "No Title";
       }


       if (Utilities.validRange(notePriority, 1, 5)) {
           this.notePriority = notePriority;
       } else {
           this.notePriority = 1;
       }


       if (noteCategory.equals("Home") ||
               noteCategory.equals("Work") ||
               noteCategory.equals("Hobby") ||
               noteCategory.equals("Holiday") ||
               noteCategory.equals("College")) {
           this.noteCategory = noteCategory;
       }


   }


    public String getNoteTitle() {
        return noteTitle;
    }

    public void setNoteTitle(String noteTitle) {
        if (Utilities.validateStringLength(noteTitle, 20)) {
            this.noteTitle = noteTitle;
        } else if (noteTitle.length() <= 0) {
            this.noteTitle = "No Title";
        }
    }

    public int getNotePriority() {
        return notePriority;
    }

    public void setNotePriority(int notePriority) {
        if (Utilities.validRange(notePriority, 1, 5)) {
            this.notePriority = notePriority;
        }
    }

    public String getNoteCategory() {
        return noteCategory;
    }

    public void setNoteCategory(String noteCategory) {
        if (noteCategory.equals("Home") ||
                noteCategory.equals("Work") ||
                noteCategory.equals("Hobby") ||
                noteCategory.equals("Holiday") ||
                noteCategory.equals("College")) {
            this.noteCategory = noteCategory;
        }
    }

    public boolean isNoteArchived() {
        return isNoteArchived;
    }

    public void setNoteArchived(boolean noteArchived) {
        isNoteArchived = noteArchived;
    }

    public ArrayList<Item> getItems() {
        return myItem;
    }

    public void setItems(ArrayList<Item> myItem) {
        this.myItem = myItem;
    }

    public int numberOfItems() {
        return myItem.size();
    }

    public boolean addItem(Item item) {
        myItem.add(item);
        return true;
    }

    public Item deleteItem(int index) {
        if (isValidIndex(index)) {
            myItem.remove(index);
        }return myItem.get(index);
    }

    public boolean updateItem(int index,String itemDescription,boolean itemCompleted) {
        for (int i = 0; i < myItem.size(); i = i + 1) {
            if (isValidIndex(index)) {
                if (i == index) {
                    myItem.get(i).setItemDescription(itemDescription);
                    myItem.get(i).setItemCompleted(itemCompleted);
                }
            }
        }
        return true;
    }


     public String listItems() {
            String itemsList = "";
            if(myItem.size() == 0){
                itemsList = "No Items";
            }else{
                for(Item item : myItem){
                    itemsList = itemsList.concat( "\n" + item.toString());
                }
            }
            return  itemsList;
        }



        public boolean checkNoteCompletionStatus(){
            for(int i = 0; i < myItem.size(); i= i+1){                  // goes through whole index and says what ones are completed
                if(myItem.get(i).isItemCompleted()==true);{
                    System.out.println(i + "is completed");
                }
            }
             return true;
        }


        public Item findItem(int index){
       if(isValidIndex(index)){                     //give index and tells you if it exists
           return myItem.get(index);
       }
            return null;
        }




        public boolean isValidIndex ( int index){             //Error handling wont add anything other than 0123
            if ((index >= 0) && (index < myItem.size())) {
                return true;
            } else {
                return false;
            }
        }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Note note = (Note) o;
        return notePriority == note.notePriority
                && isNoteArchived
                == note.isNoteArchived
                && noteTitle.equals(note.noteTitle)
                && noteCategory.equals(note.noteCategory)
                && myItem.equals(note.myItem);
    }

        @Override
        public String toString () {
            return "Note{" +
                    "noteTitle='" + noteTitle + '\'' +
                    ", notePriority=" + notePriority +
                    ", noteCategory='" + noteCategory + '\'' +
                    ", isNoteArchived=" + isNoteArchived +
                    ", items=" + myItem +
                    '}';
        }

}