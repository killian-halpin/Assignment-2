//package utils;
//
//import java.util.ArrayList;
//
//public class CategoryUtility {
//
//    public static ArrayList<String> Categories() {
//        ArrayList<String> CategoryUtility = new ArrayList<String>() {
//            {
//                add("Home");
//                add("Work");
//                add("Hobby");
//                add("Holiday");
//                add("College");
//                add("");
//
//            }
//
//
//        };
//        System.out.println("Arraylist : " + CategoryUtility);
//    }
//
//    public static boolean isValidCategory(String home) {
//    }
//}
